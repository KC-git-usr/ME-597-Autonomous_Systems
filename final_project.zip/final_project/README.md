# ME_597_final_project_env

To spawn the dynamic obstacles:

`rosrun final_project dynamic_obstacles.py`
