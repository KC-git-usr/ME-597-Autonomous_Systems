**Instructions**

1. Open final_project/src/astar_map.py, go to line 352, make sure the directory is correct
2. Do the same for line 353
3. Execute this command:
    $roslaunch final_project task_2.launch
4. To increase speed of simulation:
    *Switch to Gazebo window
    *click physics->propoerty->real time
    *set it to 2000

To fix:
1. clean up print statements